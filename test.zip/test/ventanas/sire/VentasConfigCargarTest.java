/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package ventanas.sire;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author guill
 */
public class VentasConfigCargarTest {
    
    @Test
    // Verifica la funcionalidad de cargar desde un archivo existente.
    public void testCargarDesdeArchivoExistente() {
        VentasConfig ventasConfig = new VentasConfig();

        // Caso de prueba exitoso
        boolean resultadoExitoso = ventasConfig.cargar("archivo/existente");
        assertTrue(resultadoExitoso, "La carga debería ser exitosa");
        
    }

    @Test
    // Verifica la funcionalidad de cargar desde un archivo inexistente.
    public void testCargarDesdeArchivoInexistente() {
        VentasConfig ventasConfig = new VentasConfig();

        // Caso de prueba fallido
        boolean resultadoFallido = ventasConfig.cargar("archivo/inexistente");
        assertFalse(resultadoFallido, "La carga debería fallar desde un archivo inexistente");

    }
}
