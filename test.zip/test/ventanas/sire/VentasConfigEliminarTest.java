/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package ventanas.sire;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author guill
 */
public class VentasConfigEliminarTest {
    
    @Test
    // Verifica la funcionalidad de eliminar datos existentes.
    public void testEliminarConDatos() {
        VentasConfig ventasConfig = new VentasConfig();

        // Caso de prueba exitoso
        boolean resultadoExitoso = ventasConfig.eliminar();
        assertTrue(resultadoExitoso, "La eliminación debería ser exitosa con datos existentes");

    }

    @Test
    // Verifica la funcionalidad de eliminar cuando no hay datos.
    public void testEliminarSinDatos() {
        VentasConfig ventasConfig = new VentasConfig();

        // Caso de prueba fallido
        boolean resultadoFallido = ventasConfig.eliminar();
        assertFalse(resultadoFallido, "La eliminación debería fallar sin datos");

    }
}
