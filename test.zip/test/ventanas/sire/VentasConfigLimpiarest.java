/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package ventanas.sire;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author guill
 */
public class VentasConfigLimpiarest {
    
     @Test
    // Verifica la funcionalidad de limpiar datos existentes.
    public void testLimpiarConDatos() {
        VentasConfig ventasConfig = new VentasConfig();

        // Caso de prueba exitoso
        boolean resultadoExitoso = ventasConfig.limpiar();
        assertTrue(resultadoExitoso, "La limpieza debería ser exitosa con datos existentes");

    }

    @Test
    // Verifica la funcionalidad de limpiar cuando no hay datos.
    public void testLimpiarSinDatos() {
        VentasConfig ventasConfig = new VentasConfig();

        // Caso de prueba fallido
        boolean resultadoFallido = ventasConfig.limpiar();
        assertFalse(resultadoFallido, "La limpieza debería fallar sin datos");

    }
}
