/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package ventanas.helpers;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author guill
 */
public class ActionsPerformandVisualizarTest {
    
    @Test
    // Verifica la funcionalidad de visualizar con datos válidos.
    public void testVisualizarDatosValidos() {
        ActionsPerformand actionsPerformand = new ActionsPerformand();

        // Caso de prueba exitoso
        boolean resultadoExitoso = actionsPerformand.visualizar();
        assertTrue(resultadoExitoso, "La visualización debería ser exitosa con datos válidos");

    }

    @Test
    // Verifica la funcionalidad de visualizar con datos no válidos.
    public void testVisualizarDatosNoValidos() {
        ActionsPerformand actionsPerformand = new ActionsPerformand();

        // Caso de prueba fallido
        boolean resultadoFallido = actionsPerformand.visualizar();
        assertFalse(resultadoFallido, "La visualización debería fallar con datos no válidos");

    }
}
