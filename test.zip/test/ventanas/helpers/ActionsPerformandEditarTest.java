/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package ventanas.helpers;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author guill
 */
public class ActionsPerformandEditarTest {
    
    @Test
    // Verifica la funcionalidad de editar un elemento existente.
    public void testEditarElementoExistente() {
        ActionsPerformand actionsPerformand = new ActionsPerformand();
        actionsPerformand.agregarElemento(/* elemento existente */);

        // Caso de prueba exitoso
        boolean resultadoExitoso = actionsPerformand.editar(/* elemento existente */);
        assertTrue(resultadoExitoso, "La edición debería ser exitosa con un elemento existente");

    }

    @Test
    // Verifica la funcionalidad de editar un elemento inexistente.
    public void testEditarElementoInexistente() {
        ActionsPerformand actionsPerformand = new ActionsPerformand();
        actionsPerformand.limpiar();

        // Caso de prueba fallido
        boolean resultadoFallido = actionsPerformand.editar(/* elemento inexistente */);
        assertFalse(resultadoFallido, "La edición debería fallar con un elemento inexistente");

    }
}