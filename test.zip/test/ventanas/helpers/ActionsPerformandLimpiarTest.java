/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package ventanas.helpers;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author guill
 */
public class ActionsPerformandLimpiarTest {
    
    @Test
    // Verifica la funcionalidad de limpiar cuando la lista no está vacía.
    public void testLimpiarListaNoVacia() {
        ActionsPerformand actionsPerformand = new ActionsPerformand();
        actionsPerformand.setListaDatos(/* lista no vacía */);

        // Caso de prueba exitoso
        boolean resultadoExitoso = actionsPerformand.limpiar();
        assertTrue(resultadoExitoso, "La limpieza debería ser exitosa con una lista no vacía");

    }

    @Test
    // Verifica la funcionalidad de limpiar cuando la lista está vacía.
    public void testLimpiarListaVacia() {
        ActionsPerformand actionsPerformand = new ActionsPerformand();
        actionsPerformand.setListaDatos(new ArrayList<>());

        // Caso de prueba fallido
        boolean resultadoFallido = actionsPerformand.limpiar();
        assertFalse(resultadoFallido, "La limpieza debería fallar con una lista vacía");

    }
}
