/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package ventanas.helpers;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ActionsPerformandTest {

    @Test
    // Verifica que esNumeroValido devuelve true para un número válido.
    public void testEsNumeroValido_TrueForValidNumber() {
        ActionsPerformand actions = new ActionsPerformand();
        assertTrue(actions.esNumeroValido("123.45"));
    }

    @Test
    // Verifica que esNumeroValido devuelve false para un número inválido.
    public void testEsNumeroValido_FalseForInvalidNumber() {
        ActionsPerformand actions = new ActionsPerformand();
        assertFalse(actions.esNumeroValido("abc"));
    }

    @Test
    // Verifica que dividirCadena divide correctamente la cadena dada.
    public void testDividirCadena_SplitsCorrectly() {
        ActionsPerformand actions = new ActionsPerformand();
        String cadena = "Esto es una cadena de prueba";
        int longitudMaxima = 5;

        assertEquals(6, actions.dividirCadena(cadena, longitudMaxima).size());
    }
}