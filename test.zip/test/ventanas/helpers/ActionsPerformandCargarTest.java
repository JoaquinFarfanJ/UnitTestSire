/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package ventanas.helpers;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author guill
 */
public class ActionsPerformandCargarTest {
    
    @Test
    // Verifica la funcionalidad de cargar con datos válidos.
    public void testCargarDatosValidos() {
        ActionsPerformand actionsPerformand = new ActionsPerformand();


        // Caso de prueba exitoso
        boolean resultadoExitoso = actionsPerformand.cargar();
        assertTrue(resultadoExitoso, "La carga debería ser exitosa con datos válidos");

    }

    @Test
    // Verifica la funcionalidad de cargar con datos no válidos.
    public void testCargarDatosNoValidos() {
        ActionsPerformand actionsPerformand = new ActionsPerformand();


        // Caso de prueba fallido
        boolean resultadoFallido = actionsPerformand.cargar();
        assertFalse(resultadoFallido, "La carga debería fallar con datos no válidos");

    }
}