/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package ventanas.helpers;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author guill
 */
public class ActionsPerformandSubirTest {
    
     @Test
    // Verifica la funcionalidad de subir con un archivo válido.
    public void testSubirArchivoValido() {
        ActionsPerformand actionsPerformand = new ActionsPerformand();


        // Caso de prueba exitoso
        boolean resultadoExitoso = actionsPerformand.subir();
        assertTrue(resultadoExitoso, "La subida debería ser exitosa con un archivo válido");

    }

    @Test
    // Verifica la funcionalidad de subir con un archivo no válido.
    public void testSubirArchivoNoValido() {
        ActionsPerformand actionsPerformand = new ActionsPerformand();


        // Caso de prueba fallido
        boolean resultadoFallido = actionsPerformand.subir();
        assertFalse(resultadoFallido, "La subida debería fallar con un archivo no válido");

    }
}
