/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package ventanas.helpers;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author guill
 */
public class ActionsPerformandEliminarTest {
    
    @Test
    // Verifica la funcionalidad de eliminar un elemento existente.
    public void testEliminarElementoExistente() {
        ActionsPerformand actionsPerformand = new ActionsPerformand();
        actionsPerformand.agregarElemento(/* elemento existente */);

        // Caso de prueba exitoso
        boolean resultadoExitoso = actionsPerformand.eliminar(/* elemento existente */);
        assertTrue(resultadoExitoso, "La eliminación debería ser exitosa con un elemento existente");

    }

    @Test
    // Verifica la funcionalidad de eliminar un elemento inexistente.
    public void testEliminarElementoInexistente() {
        ActionsPerformand actionsPerformand = new ActionsPerformand();
        actionsPerformand.limpiar();

        // Caso de prueba fallido
        boolean resultadoFallido = actionsPerformand.eliminar(/* elemento inexistente */);
        assertFalse(resultadoFallido, "La eliminación debería fallar con un elemento inexistente");

    }
}